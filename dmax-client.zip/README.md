# dmax-server
Static MLS server
